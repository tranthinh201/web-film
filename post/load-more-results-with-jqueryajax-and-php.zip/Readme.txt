Author: Yogesh singh
Author URL: http://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: http://makitweb.com/load-more-results-with-jqueryajax-and-php/

Instructions -

## Import attached posts.sql file in your database.
## Update database configuration in config.php file.